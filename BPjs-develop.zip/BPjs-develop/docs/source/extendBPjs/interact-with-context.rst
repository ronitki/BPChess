Interacting with the B-Program's Context
========================================

.. todo :: Write about how to interact with the context.