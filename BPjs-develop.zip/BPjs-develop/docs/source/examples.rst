================================
Examples
================================

.. include examples::

Here are some examples you can learn from:

.. toctree::
   :maxdepth: 2

   example-hot-cold
   example-dining-philosophers
   example-mazes
   example-TTT

