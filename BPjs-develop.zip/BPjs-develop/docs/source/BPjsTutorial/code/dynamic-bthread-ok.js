var COUNT=10;
for ( var i=0; i<COUNT; i++ ) {
    (function(j){
        if(parseFloat(j)%parseFloat(7)===parseFloat(0)){
            bp.registerBThread("requestor-BOOM" + j, function(){
                bp.sync({request:bp.Event("boom"+j)});
            });
        }
        else {
            bp.registerBThread("requestor-" + j, function () {
                bp.sync({request: bp.Event("e" + j)});
            });
        }
    })
    (i);
};
