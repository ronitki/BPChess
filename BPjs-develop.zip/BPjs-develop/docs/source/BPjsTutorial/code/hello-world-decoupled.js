bp.registerBThread("bt-hi", function(){
  bp.sync({request:bp.Event("hello")});
})

bp.registerBThread("bt-world",function(){
  bp.sync({request:bp.Event("world")});
})
bp.registerBThread("hello world Patch", function(){
    bp.sync({waitFor:bp.Event("hello"), block:bp.Event("world")});
})