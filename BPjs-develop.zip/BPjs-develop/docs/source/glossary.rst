================================
Terms Used in this documentation
================================

.. glossary::

  Scenario-Based Programming
    .. todo:: explain

  Behavioral Programming
    .. todo:: explain

  b-program
    .. todo:: explain

  b-thread
    .. todo:: explain

  Trace
    The sequence of events selected by a b-program during its execution. To executions are considered equivalent if (and only if) they have equal traces.
