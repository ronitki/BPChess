/**
 * This package holds "main" method classes - entry points that can be called
 * from external systems such as the command line or GUIs.
 * 
 * @author: Michael Bar-Sinai
 */
package il.ac.bgu.cs.bp.bpjs.mains;
