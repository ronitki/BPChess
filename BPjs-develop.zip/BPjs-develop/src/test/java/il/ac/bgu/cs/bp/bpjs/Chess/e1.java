package il.ac.bgu.cs.bp.bpjs.Chess;

/**
 * Created by Ronit on 02-Oct-18.
 */
public class e1 {
}
