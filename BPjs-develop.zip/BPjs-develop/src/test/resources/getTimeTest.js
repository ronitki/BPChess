/* global bp */

var theTime = bp.getTime();
bp.log.warn("Time is: " + theTime);

